package com.wh.language;

import com.intellij.codeInsight.completion.*;
import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.codeInsight.lookup.LookupElementBuilder;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.util.TextRange;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.util.Collections;

public class JSGaeaCompletionContributor extends CompletionContributor {
    public JSGaeaCompletionContributor() {
        super();
    }

//    public GaeaCompletionContributor() {
//        extend(CompletionType.BASIC, PlatformPatterns.psiElement(SimpleTypes.VALUE),
//                new CompletionProvider<>() {
//                    public void addCompletions(@NotNull CompletionParameters parameters,
//                                               @NotNull ProcessingContext context,
//                                               @NotNull CompletionResultSet resultSet) {
//                        resultSet.addElement(LookupElementBuilder.create("最终回车显示文本——也可以用来做匹配本文")
//                                .withLookupString("my额外的匹配文本1")
//                                .withLookupString("my额外的匹配文本2")
//                                .withPresentableText("一级提示文本")
//                                .withCaseSensitivity(true)//大小写不敏感
//                                .appendTailText("二级提示文本", true)
//                                //.withIcon()
//                                .withItemTextForeground(Color.BLUE)//一级提示文本颜色
//                                .withInsertHandler(new InsertHandler<LookupElement>() {
//                                    @Override
//                                    public void handleInsert(@NotNull InsertionContext context, @NotNull LookupElement item) {
//                                        Document document = context.getDocument();
//                                        int insertPosition = context.getSelectionEndOffset();
//                                        document.insertString(insertPosition, "  => ");
//                                        insertPosition += 5;
//                                        context.getEditor().getCaretModel().getCurrentCaret().moveToOffset(insertPosition);
//                                    }
//                                })
//                                .withStrikeoutness(true)//添加表示废弃的删除线
//                                .withTypeText("最右侧提示文本")
//                                .bold());
//                    }
//                }
//        );
//    }

    @Override
    public void fillCompletionVariants(@NotNull CompletionParameters parameters, @NotNull CompletionResultSet result) {
        int offset = parameters.getOffset();
        Document document = parameters.getEditor().getDocument();
        int lineStartOffset = document.getLineStartOffset(document.getLineNumber(offset));
        String text = document.getText(TextRange.create(lineStartOffset, offset));
        if (text.startsWith("global_")) {
            result.addElement(LookupElementBuilder.create("最终回车显示文本——也可以用来做匹配本文")
                    .withLookupString("my额外的匹配文本1")
                    .withLookupString("my额外的匹配文本2")
                    .withPresentableText("一级提示文本")
                    .withCaseSensitivity(true)//大小写不敏感
                    .appendTailText("二级提示文本", true)
                    //.withIcon()
                    .withItemTextForeground(Color.BLUE)//一级提示文本颜色
                    .withInsertHandler(new InsertHandler<LookupElement>() {
                        @Override
                        public void handleInsert(@NotNull InsertionContext context, @NotNull LookupElement item) {
                            Document document = context.getDocument();
                            int insertPosition = context.getSelectionEndOffset();
                            document.insertString(insertPosition, "  => ");
                            insertPosition += 5;
                            context.getEditor().getCaretModel().getCurrentCaret().moveToOffset(insertPosition);
                        }
                    })
                    .withStrikeoutness(true)//添加表示废弃的删除线
                    .withTypeText("最右侧提示文本")
                    .bold());
        } else {
            if (text.endsWith("!")) {
                return;
            }
            super.fillCompletionVariants(parameters, result);
            WordCompletionContributor.addWordCompletionVariants(result, parameters, Collections.emptySet());
        }
        result.stopHere();
    }

}